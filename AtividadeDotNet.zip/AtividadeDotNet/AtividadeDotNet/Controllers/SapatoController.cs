﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AtividadeDotNet.Entities;
using AtividadeDotNet.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AtividadeDotNet.Controllers
{
    [ApiController]
    [Route("(controller)")]
    public class SapatoController : ControllerBase
    {
        private readonly ILogger<SapatoController> _logger;
        private readonly ISapatoService _sapato;

        public SapatoController(ILogger<SapatoController> logger, ISapatoService sapato)
        {
            _logger = logger;
            _sapato = sapato;
        }
        [HttpPost]
        public IActionResult sapatoAdd([FromBody] Sapato novoSapato)
        {
            return Ok(_sapato.AdicionarSapato(novoSapato));
        }
        [HttpPut]
        public IActionResult sapatoUpdate([FromBody] Sapato novoSapato)
        {
            return Ok(_sapato.AtualizarSapato(novoSapato));
        }
        [HttpGet]
        public IActionResult TodosSapatos()
        {
            return Ok(_sapato.RetornarListaSapato());
        }

        [HttpGet("{id}")]
        public IActionResult sapato(int id)
        {
            return Ok(_sapato.RetornaSapatoPorId(id));
        }
        [HttpDelete("{id}")]
        public IActionResult sapatoDelete(int id)
        {
            return Ok(_sapato.DeletarSapato(id));
        }
    }
}
